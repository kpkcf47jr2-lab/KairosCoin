
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/coinbase-proxy.js
var coinbase_proxy_default = async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: corsHeaders()
    });
  }
  try {
    const { method, path, body, jwt } = await req.json();
    if (!jwt || !path) {
      return json({ error: "Missing jwt or path" }, 400);
    }
    const url = `https://api.coinbase.com${path}`;
    const fetchOpts = {
      method: method || "GET",
      headers: {
        "Authorization": `Bearer ${jwt}`,
        "Content-Type": "application/json"
      }
    };
    if (body && (method === "POST" || method === "PUT" || method === "PATCH")) {
      fetchOpts.body = JSON.stringify(body);
    }
    const res = await fetch(url, fetchOpts);
    const contentType = res.headers.get("Content-Type") || "";
    const text = await res.text();
    let responseBody = text;
    let responseContentType = contentType;
    if (!res.ok && !contentType.includes("application/json")) {
      responseBody = JSON.stringify({ error: text.trim() || `HTTP ${res.status}` });
      responseContentType = "application/json";
    }
    return new Response(responseBody, {
      status: res.status,
      headers: {
        ...corsHeaders(),
        "Content-Type": responseContentType
      }
    });
  } catch (err) {
    return json({ error: err.message }, 500);
  }
};
function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
}
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { ...corsHeaders(), "Content-Type": "application/json" }
  });
}
var config = {
  path: "/api/coinbase-proxy"
};
export {
  config,
  coinbase_proxy_default as default
};
